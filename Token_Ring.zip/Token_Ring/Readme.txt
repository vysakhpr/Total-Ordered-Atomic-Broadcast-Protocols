./broadcast_server <self_ip> <self_port> <token_ip> <token_port> <app_send_port> <app_recv_port> <optional flag 1>

./application <app_send_port> <app_recv_port> <proc_no>


